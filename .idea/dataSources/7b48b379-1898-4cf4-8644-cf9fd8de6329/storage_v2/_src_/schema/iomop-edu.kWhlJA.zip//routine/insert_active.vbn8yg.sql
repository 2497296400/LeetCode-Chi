create
    definer = root@`%` procedure insert_active()
begin
declare i int default 0;
declare dt date;
set i=0;
-- 当前日期
set dt = CURRENT_DATE();  
-- start transaction;
while i<365 do
INSERT INTO edu_user_activedegree (user_id,day,active_degree) VALUES (1,dt,floor(10 + RAND() * (120)));
set i=i+1;
set dt = date_sub(dt, interval 1 day);
end while;
-- commit;
end;

